public class Methodbanking{
	
	
}
